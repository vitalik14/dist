
var init = function() {
	window._client = 'freshdesk';

	return undefined;
}

document.addEventListener('DOMContentLoaded', init, false);
